# -*- coding: utf-8 -*-

import xbmcgui

xbmcgui.Dialog().ok("wareztuga.tv","wareztuga.tv encerrou!","Ler comunicado no site oficial.")
      
xbmcplugin.endOfDirectory(int(sys.argv[1]))
